This folder contains the following materials:

I. Code.
The Chinese character decomposition code in python. The code performs on the publicly available open-source ids.txt file from http://www.chise.org/ids-find with detailed references in the paper. To use this decomposition tool, in command line:
 
python decompose_chinese_file.py -d decomposition-level -x < itext > output.txt 

where "decomposition-level" is the level of decomposition you want to achieve, and you shall replace it with number "1" or "2" or "3", for instance;

"-x" means removing original characters, and you can replace "-x" with "-b" or "-a" which meaning to keep the original Chinese character in the position before or after the decomposed sequences. (-b/--before -a/--after -x/--delete)

"itext" is a sample input file where you store the Chinese sentences that are to be decomposed.

"Output.txt" is the output file where you store the decomposed Chinese characters.


II. Corpora.
We offer the decomposed Chinese Multi-word Expression (MWE) terms in the folder "MWE_decomposed" in three decomposed levels, and they are parallel with the corresponding English terms. The parallel translation probability threshold is 0.85 for filtering.


We hope this free decomposition tool and the decomposed bilingual MWEs can help the community on advancing the research. 
