import sys
import re
import unicodedata


def eprint(*args, **kwargs):
    """ Just like the print function, but on stderr
    """
    print(*args, file=sys.stderr, **kwargs)


def _add_char(prc_dict, char, radicals):
    # we take the first radical or the one marked with [G]
    # as [G] should be PRC
    # http://www.unicode.org/reports/tr38/tr38-27.html
    first = True
    for r in radicals:
        m = re.search(_add_char.category, r)
        if ( m  and 'G' in m.group(0) )  or  first:
            radical = r
        first = False
    if m: radical = radical[:m.start()]
    radical = ''.join( filter(lambda c : unicodedata.category(c) in ('No', 'Lo'), radical) )

    prc_dict[char] = radical
    return prc_dict

_add_char.category = re.compile(r'\[[A-Z]*\]$')


def _make_prc_dict():
    prc_dict = {}
    with open('ids.txt', mode="r", encoding="utf-8") as ids:
        while True:
            line = ids.readline()
            if line == '': break
            if line[0] == '#': continue

            if line[-1] == '\n': line = line[:-1]

            line = line.split('\t', 2)
            line[2] = line[2].split('\t')

            prc_dict = _add_char(prc_dict, line[1], line[2])
    return prc_dict





def decompose(char, level, safe=False):
    if safe:
        return _decompose_impl(char, level, _get_safely)
    else:
        return _decompose_impl(char, level, _get_unsafely)


def _get_unsafely(d, v):
    return d[v]


def _get_safely(d, v):
    return d.get(v, v)


def _decompose_impl(char, level, getter):
    levels = [ char ]
    for l in range(0, level):
        nlevel = []
        for c in levels[l]:
            nlevel.append( getter(_decompose_impl.dict, c) )
        nlevel = ''.join(nlevel)
        if nlevel == levels[-1]: #fixed point
            break
        levels.append( nlevel )
    return levels
_decompose_impl.dict = _make_prc_dict()

