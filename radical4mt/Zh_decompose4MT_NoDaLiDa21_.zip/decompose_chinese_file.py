#!/usr/bin/env python3

import sys
from ids_dict import decompose
import argparse


def eprint(*args, **kwargs):
    """ Just like the print function, but on stderr
    """
    print(*args, file=sys.stderr, **kwargs)


def compose(how, char, decomposition):
    if len(decomposition) == 1: return [ decomposition ]

    if how.delete:
        return [ decomposition ]
    elif how.before:
        return [ char, decomposition ]
    else:
        return [ decomposition, char ]


def rmain(args):
    for line in sys.stdin:
        oline = []
        for c in line:
            decomposition = decompose(c, args.decomposition, True)
            oline.extend( compose(args, c, decomposition[-1]) )
        print(''.join(oline), end ='')
    return 0




def main(argv=None):
    if argv is None:
        argv = sys.argv
    parser = argparse.ArgumentParser( argv )
    parser.add_argument("-d", "--decomposition", default=2, type=int, help="How depth is the decomposition")
    group = parser.add_mutually_exclusive_group(required="True")

    group.add_argument("-b", "--before", help="Put the original character before the decomposition", action="store_true")
    group.add_argument("-a", "--after", help="Put the original character after the decomposition", action="store_true")
    group.add_argument("-x", "--delete", help="Removes the original character", action="store_true")

    args = parser.parse_args()

    return rmain(args)

if __name__ == "__main__":
    sys.exit(main())
